/**
 * Robotics Lessons Module
 * Robot arm, drone, and mechanical systems education
 * Ultra-High-Quality Models with Individual Part Interaction
 */

import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { CustomAssets } from '../custom-assets.js';

// Helper: Create a curved cable
function createCable(points, color = 0x222222, thickness = 0.02) {
  const curve = new THREE.CatmullRomCurve3(points);
  const geo = new THREE.TubeGeometry(curve, 20, thickness, 8, false);
  const mat = new THREE.MeshStandardMaterial({ color, roughness: 0.7, metalness: 0.1 });
  return new THREE.Mesh(geo, mat);
}

// Helper: Create a bolt head
function createBoltHead(scale = 1, color = 0x888888) {
  const geo = new THREE.CylinderGeometry(0.02 * scale, 0.02 * scale, 0.01 * scale, 6);
  const mat = new THREE.MeshStandardMaterial({ color, metalness: 0.8, roughness: 0.3 });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.rotation.x = Math.PI / 2;
  return mesh;
}

// Helper: Create a gear-like cylinder
function createGear(radius, height, teeth, color) {
  const group = new THREE.Group();
  const core = new THREE.Mesh(
    new THREE.CylinderGeometry(radius * 0.8, radius * 0.8, height, 16),
    new THREE.MeshStandardMaterial({ color })
  );
  group.add(core);

  const toothGeo = new THREE.BoxGeometry(radius * 0.3, height, radius * 0.3);
  const toothMat = new THREE.MeshStandardMaterial({ color });
  for (let i = 0; i < teeth; i++) {
    const angle = (i / teeth) * Math.PI * 2;
    const tooth = new THREE.Mesh(toothGeo, toothMat);
    tooth.position.set(Math.cos(angle) * radius, 0, Math.sin(angle) * radius);
    tooth.rotation.y = -angle;
    group.add(tooth);
  }
  return group;
}

export const RoboticsLessons = {
  // 6-DOF Robot Arm
  robotArm: {
    id: 'robot-arm',
    name: '6축 로봇팔 (Ultra)',
    subject: 'engineering',
    topic: 'robotics',
    description: '산업용 6축 로봇팔의 정밀한 구조와 각 관절의 역할을 학습합니다.',
    concepts: ['자유도(DOF)', '관절(Joint)', '엔드이펙터', '역기구학'],

    setup: (scene, physics, THREE) => {
      const group = new THREE.Group();
      group.name = 'RobotArm';

      const gltfLoader = new GLTFLoader();

      const loadPart = (key, partDef, parentGroup, fallbackMeshGen) => {
        const custom = CustomAssets.robotArm ? CustomAssets.robotArm[key] : null;

        const partGroup = new THREE.Group();
        partGroup.name = partDef.name;
        partGroup.userData = { part: partDef, originalPosition: partGroup.position.clone(), isSelectable: true };

        if (custom && custom.url) {
          gltfLoader.load(custom.url, (gltf) => {
            const model = gltf.scene;
            model.scale.setScalar(custom.scale || 1.0);
            if (custom.rotation) model.rotation.set(custom.rotation.x, custom.rotation.y, custom.rotation.z);
            if (custom.position) model.position.set(custom.position.x, custom.position.y, custom.position.z);

            model.traverse(child => {
              if (child.isMesh) {
                child.castShadow = true;
                child.receiveShadow = true;
              }
            });

            partGroup.clear();
            partGroup.add(model);
          }, undefined, (err) => {
            console.warn(`Failed to load custom asset ${custom.url}`, err);
            fallbackMeshGen(partGroup);
          });

          // Initial placeholder/fallback
          fallbackMeshGen(partGroup);
        } else {
          fallbackMeshGen(partGroup);
        }

        parentGroup.add(partGroup);
        return partGroup;
      };

      // Part definitions
      const parts = {
        base: {
          name: '베이스 (Base)',
          description: '로봇팔의 기초. 지면에 고정되어 전체를 지지합니다.',
          color: 0x1a1a2e,
          explosionOffset: new THREE.Vector3(0, -0.2, 0)
        },
        shoulder: {
          name: '어깨 관절 (Joint 1)',
          description: '수직축 회전. 로봇팔의 좌우 회전을 담당합니다.',
          color: 0x16213e,
          explosionOffset: new THREE.Vector3(0, 0.1, 0)
        },
        upperArm: {
          name: '상완 (Upper Arm)',
          description: '어깨에서 팔꿈치까지의 링크입니다.',
          color: 0xf39c12, // Industrial Orange
          explosionOffset: new THREE.Vector3(0, 0.3, 0)
        },
        elbow: {
          name: '팔꿈치 관절 (Joint 3)',
          description: '수평축 회전. 팔의 굽힘을 담당합니다.',
          color: 0x2c3e50,
          explosionOffset: new THREE.Vector3(0, 0.5, 0)
        },
        forearm: {
          name: '전완 (Forearm)',
          description: '팔꿈치에서 손목까지의 링크입니다.',
          color: 0xf39c12,
          explosionOffset: new THREE.Vector3(0.3, 0.3, 0)
        },
        wrist: {
          name: '손목 관절 (Wrist)',
          description: '3축 회전으로 정밀한 방향 제어를 합니다.',
          color: 0x2c3e50,
          explosionOffset: new THREE.Vector3(0.5, 0.3, 0)
        },
        endEffector: {
          name: '엔드 이펙터 (Gripper)',
          description: '물체를 잡거나 도구를 부착하는 끝단 장치입니다.',
          color: 0x95a5a6,
          explosionOffset: new THREE.Vector3(0.7, 0.3, 0)
        }
      };

      const meshes = {};

      // Material Presets
      const mats = {
        industrial: new THREE.MeshStandardMaterial({ color: 0xf39c12, roughness: 0.3, metalness: 0.4 }),
        darkMetal: new THREE.MeshStandardMaterial({ color: 0x2c3e50, roughness: 0.5, metalness: 0.7 }),
        chrome: new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.1, metalness: 0.9 }),
        base: new THREE.MeshStandardMaterial({ color: 0x1a1a2e, roughness: 0.7, metalness: 0.4 }),
        rubber: new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.9, metalness: 0.1 })
      };

      // 1. Base
      meshes.base = loadPart('base', parts.base, group, (grp) => {
        const basePlate = new THREE.Mesh(new THREE.CylinderGeometry(0.8, 1, 0.2, 32), mats.base);
        basePlate.position.y = 0.1;
        grp.add(basePlate);

        const baseCyl = new THREE.Mesh(new THREE.CylinderGeometry(0.6, 0.8, 0.3, 32), mats.darkMetal);
        baseCyl.position.y = 0.35;
        grp.add(baseCyl);

        for (let i = 0; i < 8; i++) {
          const angle = (i / 8) * Math.PI * 2;
          const bolt = createBoltHead(1.5);
          bolt.rotation.x = 0;
          bolt.position.set(Math.cos(angle) * 0.85, 0.2, Math.sin(angle) * 0.85);
          grp.add(bolt);
        }
        const pwrConn = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.15, 0.1), new THREE.MeshStandardMaterial({ color: 0x333333 }));
        pwrConn.position.set(-0.7, 0.2, 0);
        grp.add(pwrConn);
      });
      meshes.base.originalPosition = meshes.base.position.clone();

      // 2. Shoulder
      meshes.shoulder = loadPart('shoulder', parts.shoulder, group, (grp) => {
        grp.position.y = 0.5;
        const shoulderRotator = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.6, 0.5, 32), mats.industrial);
        shoulderRotator.position.y = 0.25;
        grp.add(shoulderRotator);

        const jointHinge = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 0.7, 32), mats.darkMetal);
        jointHinge.rotation.z = Math.PI / 2;
        jointHinge.position.set(0, 0.6, 0);
        grp.add(jointHinge);

        const logoPlate = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.15), new THREE.MeshStandardMaterial({ color: 0xffffff, side: THREE.DoubleSide }));
        logoPlate.position.set(0, 0.4, 0.51);
        grp.add(logoPlate);
      });

      // 3. Upper Arm
      meshes.upperArm = loadPart('upperArm', parts.upperArm, group, (grp) => {
        grp.position.set(0, 1.1, 0);

        const armShape = new THREE.Group();
        const mainBeam = new THREE.Mesh(new THREE.BoxGeometry(0.4, 1.2, 0.3), mats.industrial);
        armShape.add(mainBeam);

        const motorHousing = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 0.3, 16), mats.darkMetal);
        motorHousing.rotation.z = Math.PI / 2;
        motorHousing.position.set(-0.2, -0.4, 0);
        armShape.add(motorHousing);

        armShape.position.y = 0.6;
        grp.add(armShape);

        const cable1 = createCable([
          new THREE.Vector3(0, 0, 0.2),
          new THREE.Vector3(0, 0.5, 0.25),
          new THREE.Vector3(0, 1.0, 0.2)
        ], 0x111111, 0.03);
        grp.add(cable1);
      });

      // 4. Elbow
      meshes.elbow = loadPart('elbow', parts.elbow, group, (grp) => {
        grp.position.set(0, 2.3, 0);
        const elbowCyl = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 0.5, 32), mats.darkMetal);
        elbowCyl.rotation.z = Math.PI / 2;
        grp.add(elbowCyl);

        const elbowCover = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.4, 0.1, 32), mats.chrome);
        elbowCover.rotation.z = Math.PI / 2;
        elbowCover.position.x = 0.26;
        grp.add(elbowCover);

        for (let i = 0; i < 6; i++) {
          const ang = (i / 6) * Math.PI * 2;
          const b = createBoltHead(1.0);
          b.rotation.x = 0;
          b.rotation.z = Math.PI / 2;
          b.position.set(0.32, Math.cos(ang) * 0.25, Math.sin(ang) * 0.25);
          grp.add(b);
        }
      });

      // 5. Forearm
      meshes.forearm = loadPart('forearm', parts.forearm, group, (grp) => {
        grp.position.set(0.5, 2.3, 0);
        grp.rotation.z = -Math.PI / 2; // Horizontal

        const foreShape = new THREE.CylinderGeometry(0.2, 0.15, 1.2, 16);
        const foreMesh = new THREE.Mesh(foreShape, mats.industrial);
        foreMesh.position.y = 0.6;
        grp.add(foreMesh);

        const wiringTube = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.0, 8), mats.rubber);
        wiringTube.position.set(0, 0.6, 0.22);
        grp.add(wiringTube);
      });

      // 6. Wrist
      meshes.wrist = loadPart('wrist', parts.wrist, group, (grp) => {
        grp.position.set(1.7, 2.3, 0);
        const wristSphere = new THREE.Mesh(new THREE.SphereGeometry(0.25, 32, 32), mats.darkMetal);
        grp.add(wristSphere);
        const wristRing = new THREE.Mesh(new THREE.TorusGeometry(0.25, 0.05, 16, 32), mats.chrome);
        grp.add(wristRing);
      });

      // 7. End Effector
      meshes.endEffector = loadPart('endEffector', parts.endEffector, group, (grp) => {
        grp.position.set(2.0, 2.3, 0);
        const mount = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 0.05, 16), mats.darkMetal);
        mount.rotation.z = Math.PI / 2;
        grp.add(mount);

        const body = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.3, 0.15), mats.industrial);
        body.position.x = 0.1;
        grp.add(body);

        const fingerGeo = new THREE.BoxGeometry(0.4, 0.03, 0.08);

        const f1 = new THREE.Mesh(fingerGeo, mats.chrome);
        f1.position.set(0.3, 0.1, 0);
        grp.add(f1);
        const pad1 = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.02, 0.08), mats.rubber);
        pad1.position.set(0.45, 0.08, 0);
        grp.add(pad1);

        const f2 = new THREE.Mesh(fingerGeo, mats.chrome);
        f2.position.set(0.3, -0.1, 0);
        grp.add(f2);
        const pad2 = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.02, 0.08), mats.rubber);
        pad2.position.set(0.45, -0.08, 0);
        grp.add(pad2);
      });

      // Initialize
      group.userData.meshes = meshes;
      group.userData.parts = parts;
      group.position.set(0, 0, 0);
      scene.add(group);

      return { objects: [group], mainObject: group, meshes, parts };
    },

    onUpdate: (objects, delta) => {
      const group = objects[0];
      if (!group.userData.meshes) return;

      const isExploded = group.userData.isExploded;
      const targetProgress = isExploded ? 1 : 0;

      if (Math.abs(group.userData.explosionProgress - targetProgress) > 0.001) {
        group.userData.explosionProgress += (targetProgress - group.userData.explosionProgress) * 2 * delta;
        Object.values(group.userData.meshes).forEach(mesh => {
          const part = mesh.userData.part;
          const original = mesh.userData.originalPosition;
          if (part && original) {
            const offset = part.explosionOffset.clone().multiplyScalar(group.userData.explosionProgress);
            mesh.position.copy(original).add(offset);
          }
        });
      }
    },

    toggleExplode: (objects) => {
      const group = objects[0];
      group.userData.isExploded = !group.userData.isExploded;
      if (group.userData.explosionProgress === undefined) group.userData.explosionProgress = 0;
    },

    getInfo: () => ({
      title: '6축 로봇팔 (Ultra)',
      data: {
        '모델': 'IRB-6700 타입',
        '페이로드': '150kg ~ 300kg',
        '특징': '유압/공압 라인 통합',
        '용도': '스폿 용접, 자재 핸들링, 조립'
      }
    })
  },

  // Quadcopter Drone
  drone: {
    id: 'drone',
    name: '레이싱 드론 (Pro)',
    subject: 'engineering',
    topic: 'robotics',
    description: '고성능 레이싱 드론의 공기역학적 구조와 전자 장치를 학습합니다.',
    concepts: ['양력', '추력', '카본 프레임', 'BLDC 모터'],

    setup: (scene, physics, THREE) => {
      const group = new THREE.Group();
      group.name = 'Drone';

      const parts = {
        frame: { name: 'Carbon Frame', color: 0x222222, explosionOffset: new THREE.Vector3(0, 0, 0) },
        topPlate: { name: 'Top Deck', color: 0x222222, explosionOffset: new THREE.Vector3(0, 0.4, 0) },
        battery: { name: 'LiPo 4S 1500mAh', color: 0xf1c40f, explosionOffset: new THREE.Vector3(0, 0.6, 0) },
        fc: { name: 'F7 Flight Controller', color: 0xe74c3c, explosionOffset: new THREE.Vector3(0, 0.2, 0) },
        camera: { name: 'FPV Camera', color: 0x95a5a6, explosionOffset: new THREE.Vector3(0, 0.1, 0.5) },
        antenna: { name: '5.8GHz Antenna', color: 0xe74c3c, explosionOffset: new THREE.Vector3(0, 0.5, -0.5) }
      };

      const meshes = {};
      const matCarbon = new THREE.MeshStandardMaterial({
        color: 0x111111, roughness: 0.6, metalness: 0.3,
        bumpScale: 0.02
        // If we had texture, we'd add carbon fiber pattern here
      });
      const matAlu = new THREE.MeshStandardMaterial({ color: 0xe67e22, roughness: 0.2, metalness: 0.9 });
      const matProp = new THREE.MeshStandardMaterial({ color: 0xecf0f1, transparent: true, opacity: 0.95, roughness: 0.1 });

      // 1. Arm X Frame
      const frameGroup = new THREE.Group();
      // X Arms with chamfered edges (simulated by scaling boxes)
      const armGeo = new THREE.BoxGeometry(0.3, 0.04, 2);
      const arm1 = new THREE.Mesh(armGeo, matCarbon);
      arm1.rotation.y = Math.PI / 4;
      frameGroup.add(arm1);
      const arm2 = new THREE.Mesh(armGeo, matCarbon);
      arm2.rotation.y = -Math.PI / 4;
      frameGroup.add(arm2);

      // Standoffs
      for (let i = 0; i < 4; i++) {
        const standoff = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.3, 8), new THREE.MeshStandardMaterial({ color: 0xff0000 }));
        const x = (i % 2 === 0 ? 0.3 : -0.3);
        const z = (i < 2 ? 0.3 : -0.3);
        standoff.position.set(x, 0.15, z);
        frameGroup.add(standoff);
      }

      frameGroup.userData = { part: parts.frame, originalPosition: new THREE.Vector3(0, 0, 0), isSelectable: true };
      frameGroup.name = 'Frame';
      group.add(frameGroup);
      meshes.frame = frameGroup;

      // 2. Flight Stack
      const stackGroup = new THREE.Group();
      // FC
      const fc = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.05, 0.3), new THREE.MeshStandardMaterial({ color: 0xe74c3c }));
      fc.position.y = 0.15;
      stackGroup.add(fc);
      // ESC
      const esc = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.05, 0.35), new THREE.MeshStandardMaterial({ color: 0x2c3e50 }));
      esc.position.y = 0.05;
      stackGroup.add(esc);

      // Capacitor
      const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.2, 16), new THREE.MeshStandardMaterial({ color: 0x333333 }));
      cap.rotation.z = Math.PI / 2;
      cap.position.set(-0.25, 0.05, -0.1);
      stackGroup.add(cap);

      stackGroup.userData = { part: parts.fc, originalPosition: new THREE.Vector3(0, 0, 0), isSelectable: true };
      stackGroup.name = 'Electronics';
      group.add(stackGroup);
      meshes.fc = stackGroup;

      // 3. Top Plate
      const topGroup = new THREE.Group();
      const plate = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.02, 1.2), matCarbon);
      plate.position.y = 0.3;
      topGroup.add(plate);

      // Battery Straps
      const strap = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.01, 8, 32), new THREE.MeshStandardMaterial({ color: 0x000000 }));
      strap.rotation.x = Math.PI / 2;
      strap.scale.set(1.1, 1, 1);
      strap.position.y = 0.31;
      topGroup.add(strap);

      topGroup.userData = { part: parts.topPlate, originalPosition: new THREE.Vector3(0, 0, 0), isSelectable: true };
      topGroup.name = 'TopPlate';
      group.add(topGroup);
      meshes.topPlate = topGroup;

      // 4. Battery
      const batGroup = new THREE.Group();
      const batBody = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.25, 0.9), new THREE.MeshStandardMaterial({ color: 0x222222 })); // Shrink wrap
      batBody.position.y = 0.45;
      batGroup.add(batBody);

      const batLabel = new THREE.Mesh(new THREE.PlaneGeometry(0.4, 0.7), new THREE.MeshBasicMaterial({ color: 0xf1c40f }));
      batLabel.rotation.x = -Math.PI / 2;
      batLabel.position.y = 0.58;
      batGroup.add(batLabel);

      // XT60 Connector
      const conn = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.1, 0.1), new THREE.MeshStandardMaterial({ color: 0xffff00 }));
      conn.position.set(0, 0.4, -0.5);
      batGroup.add(conn);

      batGroup.userData = { part: parts.battery, originalPosition: new THREE.Vector3(0, 0, 0), isSelectable: true };
      batGroup.name = 'Battery';
      group.add(batGroup);
      meshes.battery = batGroup;

      // 5. Motors & Props
      const motorLocs = [
        { id: 'm1', x: 0.7, z: 0.7, dir: 1, color: 0xe67e22 },
        { id: 'm2', x: -0.7, z: 0.7, dir: -1, color: 0xe67e22 },
        { id: 'm3', x: -0.7, z: -0.7, dir: 1, color: 0xe67e22 },
        { id: 'm4', x: 0.7, z: -0.7, dir: -1, color: 0xe67e22 },
      ];

      motorLocs.forEach((m, i) => {
        // Motor Group
        const mGroup = new THREE.Group();
        mGroup.position.set(m.x, 0.02, m.z);

        // Bell with cooling fins texture (geometry)
        const bell = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 0.2, 32), matAlu);
        bell.position.y = 0.1;
        mGroup.add(bell);

        // Shaft
        const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.3, 8), new THREE.MeshStandardMaterial({ color: 0x888888 }));
        shaft.position.y = 0.15;
        mGroup.add(shaft);

        mGroup.userData = { part: { name: `Motor ${i + 1}`, explosionOffset: new THREE.Vector3(m.x * 0.5, 0, m.z * 0.5) }, originalPosition: mGroup.position.clone(), isSelectable: true };
        mGroup.name = `Motor_${i + 1}`;
        group.add(mGroup);
        meshes[`motor${i + 1}`] = mGroup;

        // Propeller Group - Curved Blades
        const pGroup = new THREE.Group();
        pGroup.position.set(m.x, 0.2, m.z);

        for (let k = 0; k < 3; k++) {
          // Creating a twisted blade using scaling and rotation on a simple box is hard, let's use a plane and warp geometry or just thin box
          // Simple: Thin box, rotated
          const blade = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.01, 0.1), matProp);
          blade.position.set(0.3, 0, 0);

          // Tilt for pitch
          blade.rotation.x = 0.2 * m.dir;

          const bladeHolder = new THREE.Group();
          bladeHolder.rotation.y = (k * Math.PI * 2) / 3;
          bladeHolder.add(blade);
          pGroup.add(bladeHolder);
        }

        // Prop Nut
        const nut = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.02, 6), new THREE.MeshStandardMaterial({ color: m.dir > 0 ? 0xcccccc : 0x333333 }));
        nut.position.y = 0.02;
        pGroup.add(nut);

        pGroup.userData = {
          part: { name: `Prop ${i + 1}`, explosionOffset: new THREE.Vector3(m.x * 0.5, 0.5, m.z * 0.5) },
          originalPosition: pGroup.position.clone(),
          isSelectable: true,
          rotationSpeed: m.dir * 25
        };
        pGroup.name = `Prop_${i + 1}`;
        group.add(pGroup);
        meshes[`prop${i + 1}`] = pGroup;
      });

      // 6. Camera
      const camGroup = new THREE.Group();
      camGroup.position.set(0, 0.15, 0.5);

      const camBody = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, 0.1), new THREE.MeshStandardMaterial({ color: 0xf39c12 })); // Orange Runcam style
      camGroup.add(camBody);

      const lensHousing = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.08, 16), new THREE.MeshStandardMaterial({ color: 0x111111 }));
      lensHousing.rotation.x = Math.PI / 2;
      lensHousing.position.z = 0.06;
      camGroup.add(lensHousing);

      const lensGlass = new THREE.Mesh(new THREE.SphereGeometry(0.03, 16, 16), new THREE.MeshStandardMaterial({
        color: 0x220033, metalness: 0.9, roughness: 0.1, emissive: 0x110022, emissiveIntensity: 0.2
      }));
      lensGlass.position.z = 0.1;
      camGroup.add(lensGlass);

      camGroup.userData = { part: parts.camera, originalPosition: camGroup.position.clone(), isSelectable: true };
      camGroup.name = 'Camera';
      group.add(camGroup);
      meshes.camera = camGroup;

      // 7. Antenna
      const antGroup = new THREE.Group();
      antGroup.position.set(0, 0.35, -0.6);

      const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 0.3), new THREE.MeshStandardMaterial({ color: 0x000000 }));
      antGroup.add(stem);

      const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.05), new THREE.MeshStandardMaterial({ color: 0xe74c3c }));
      bulb.position.y = 0.15;
      antGroup.add(bulb);

      antGroup.rotation.x = -Math.PI / 4;

      antGroup.userData = { part: parts.antenna, originalPosition: antGroup.position.clone(), isSelectable: true };
      antGroup.name = "Antenna";
      group.add(antGroup);
      meshes.antenna = antGroup;

      group.userData.meshes = meshes;
      group.userData.isExploded = false;
      group.userData.explosionProgress = 0;
      group.position.y = 1;
      scene.add(group);

      return { objects: [group], mainObject: group, meshes };
    },

    onUpdate: (objects, delta) => {
      const group = objects[0];
      if (!group.userData.meshes) return;

      const isExploded = group.userData.isExploded;
      const targetProgress = isExploded ? 1 : 0;

      // Prop rotation
      Object.keys(group.userData.meshes).forEach(key => {
        if (key.startsWith('prop')) {
          const prop = group.userData.meshes[key];
          if (prop.userData.rotationSpeed && !isExploded) {
            prop.rotation.y += prop.userData.rotationSpeed * delta;
          }
        }
      });

      // Explosion Animation
      if (Math.abs(group.userData.explosionProgress - targetProgress) > 0.001) {
        group.userData.explosionProgress += (targetProgress - group.userData.explosionProgress) * 2 * delta;

        Object.values(group.userData.meshes).forEach(mesh => {
          const part = mesh.userData.part;
          const original = mesh.userData.originalPosition;
          if (part && original) {
            const offset = part.explosionOffset.clone().multiplyScalar(group.userData.explosionProgress);
            mesh.position.copy(original).add(offset);
          }
        });
      }
    },

    toggleExplode: (objects) => {
      const group = objects[0];
      group.userData.isExploded = !group.userData.isExploded;
      if (group.userData.explosionProgress === undefined) group.userData.explosionProgress = 0;
    },

    getInfo: () => ({
      title: '레이싱 드론 (Ultima)',
      data: {
        'Top Speed': '180km/h+',
        '배터리': '4S 1500mAh 100C',
        '모터': '2306 2450KV Brushless',
        '카메라': 'Runcam Phoenix 2'
      }
    })
  },

  // Servo Motor (Ultra)
  servoMotor: {
    id: 'servo-motor',
    name: '서보모터 분해도 (Ultra)',
    subject: 'engineering',
    topic: 'actuators',
    description: '서보모터 내부 기어박스와 전자회로를 상세 확인합니다.',
    concepts: ['기어비', 'DC 모터', '포텐셔미터', 'PWM'],

    setup: (scene, physics, THREE) => {
      const group = new THREE.Group();
      group.name = 'ServoMotor';

      const meshes = {};

      // Case Bottom - Transparent Plastic
      const caseBotGeo = new THREE.BoxGeometry(1, 0.8, 0.5);
      const caseBotMat = new THREE.MeshPhysicalMaterial({
        color: 0x333333,
        transmission: 0.2,
        opacity: 0.9,
        metalness: 0,
        roughness: 0.2
      });
      const caseBot = new THREE.Mesh(caseBotGeo, caseBotMat);
      caseBot.position.y = 0;
      caseBot.userData = { part: { name: 'Case Bottom', explosionOffset: new THREE.Vector3(0, -0.5, 0) }, originalPosition: caseBot.position.clone(), isSelectable: true };
      group.add(caseBot);
      meshes.caseBot = caseBot;

      // Motor
      const motor = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 0.6), new THREE.MeshStandardMaterial({ color: 0x95a5a6, metalness: 0.8 }));
      motor.rotation.z = Math.PI / 2;
      motor.position.set(-0.2, 0.1, 0);
      motor.userData = { part: { name: 'DC Motor', explosionOffset: new THREE.Vector3(-0.5, 0, 0) }, originalPosition: motor.position.clone(), isSelectable: true };
      group.add(motor);
      meshes.motor = motor;

      // Gears - Real teeth 
      const g1 = createGear(0.1, 0.1, 8, 0xffffff);
      g1.position.set(0.2, 0.1, 0);
      g1.userData = { part: { name: 'Main Gear', explosionOffset: new THREE.Vector3(0.5, 0.5, 0) }, originalPosition: g1.position.clone(), isSelectable: true };
      group.add(g1);
      meshes.gears = g1;

      const g2 = createGear(0.15, 0.05, 12, 0xffffff);
      g2.position.set(0.2, 0, 0.15);
      g2.userData = { part: { name: 'Secondary Gear', explosionOffset: new THREE.Vector3(0.6, 0.3, 0.2) }, originalPosition: g2.position.clone(), isSelectable: true };
      group.add(g2);
      meshes.gears2 = g2;

      // PCB
      const pcb = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.02, 0.4), new THREE.MeshStandardMaterial({ color: 0x27ae60 }));
      pcb.position.set(0, -0.2, 0);
      pcb.userData = { part: { name: 'Controller PCB', explosionOffset: new THREE.Vector3(0, -0.8, 0) }, originalPosition: pcb.position.clone(), isSelectable: true };
      group.add(pcb);
      meshes.pcb = pcb;

      // Top Cover
      const caseTop = new THREE.Mesh(new THREE.BoxGeometry(1, 0.2, 0.5), new THREE.MeshStandardMaterial({ color: 0x333333 }));
      caseTop.position.y = 0.5;
      caseTop.userData = { part: { name: 'Top Cover', explosionOffset: new THREE.Vector3(0, 1, 0) }, originalPosition: caseTop.position.clone(), isSelectable: true };
      group.add(caseTop);
      meshes.caseTop = caseTop;

      // Output Spline
      const spline = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.1, 12), new THREE.MeshStandardMaterial({ color: 0xc0c0c0 }));
      spline.position.set(0.2, 0.65, 0);
      spline.userData = { part: { name: 'Output Spline', explosionOffset: new THREE.Vector3(0, 1.2, 0) }, originalPosition: spline.position.clone(), isSelectable: true };
      group.add(spline);
      meshes.spline = spline;

      group.userData.meshes = meshes;
      group.userData.isExploded = false;
      group.position.y = 1;
      scene.add(group);
      return { objects: [group], mainObject: group, meshes };
    },

    onUpdate: (objects, delta) => {
      const group = objects[0];
      const isExploded = group.userData.isExploded;
      const target = isExploded ? 1 : 0;
      if (!group.userData.progress) group.userData.progress = 0;

      if (Math.abs(group.userData.progress - target) > 0.01) {
        group.userData.progress += (target - group.userData.progress) * 2 * delta;
        Object.values(group.userData.meshes).forEach(mesh => {
          if (mesh.userData.part) {
            mesh.position.copy(mesh.userData.originalPosition).add(mesh.userData.part.explosionOffset.clone().multiplyScalar(group.userData.progress));
          }
        });
      }

      // Spin gears if not exploded
      if (!isExploded && group.userData.meshes.gears) {
        group.userData.meshes.gears.rotation.y += delta;
      }
    },

    toggleExplode: (objects) => {
      const group = objects[0];
      group.userData.isExploded = !group.userData.isExploded;
    },

    getInfo: () => ({ title: '서보모터 (Ultra)', data: { '기어 재질': '나일론 / 메탈', '방수 등급': 'IP54' } })
  }
};

export function getAllRoboticsLessons() { return Object.values(RoboticsLessons); }
export function getRoboticsLessonById(id) { return Object.values(RoboticsLessons).find(lesson => lesson.id === id); }
export default RoboticsLessons;
