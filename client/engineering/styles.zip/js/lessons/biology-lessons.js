/**
 * Biology Lessons Module
 * 3D models and visualizations for biology education
 */

import * as THREE from 'three';

export const BiologyLessons = {
  // Animal Cell Structure
  animalCell: {
    id: 'animal-cell',
    name: '동물세포 구조',
    subject: 'biology',
    topic: 'cell',
    description: '동물세포의 구조와 각 소기관의 기능을 학습합니다.',
    concepts: ['세포막', '핵', '미토콘드리아', '리보솜', '소포체'],

    setup: (scene, physics, THREE) => {
      const group = new THREE.Group();
      group.name = 'AnimalCell';

      // Cell membrane (outer sphere)
      const membraneGeo = new THREE.SphereGeometry(3, 64, 64);
      const membraneMat = new THREE.MeshStandardMaterial({
        color: 0xfcd34d,
        transparent: true,
        opacity: 0.3,
        side: THREE.DoubleSide
      });
      const membrane = new THREE.Mesh(membraneGeo, membraneMat);
      membrane.name = '세포막';
      membrane.userData.info = '세포를 둘러싸고 있는 얇은 막으로, 물질의 출입을 조절합니다.';
      group.add(membrane);

      // Nucleus (center sphere)
      const nucleusGeo = new THREE.SphereGeometry(1, 32, 32);
      const nucleusMat = new THREE.MeshStandardMaterial({
        color: 0x7c3aed,
        metalness: 0.2,
        roughness: 0.6
      });
      const nucleus = new THREE.Mesh(nucleusGeo, nucleusMat);
      nucleus.name = '핵';
      nucleus.userData.info = '유전 정보(DNA)를 담고 있으며 세포의 활동을 조절합니다.';
      group.add(nucleus);

      // Nucleolus
      const nucleolusGeo = new THREE.SphereGeometry(0.3, 16, 16);
      const nucleolusMat = new THREE.MeshStandardMaterial({
        color: 0x4c1d95
      });
      const nucleolus = new THREE.Mesh(nucleolusGeo, nucleolusMat);
      nucleolus.position.set(0.3, 0.2, 0.4);
      nucleolus.name = '인';
      nucleolus.userData.info = '리보솜 RNA를 합성하는 곳입니다.';
      group.add(nucleolus);

      // Mitochondria (multiple)
      for (let i = 0; i < 5; i++) {
        const mitoGeo = new THREE.CapsuleGeometry(0.2, 0.5, 8, 16);
        const mitoMat = new THREE.MeshStandardMaterial({
          color: 0xef4444
        });
        const mito = new THREE.Mesh(mitoGeo, mitoMat);
        const angle = (i / 5) * Math.PI * 2;
        mito.position.set(
          Math.cos(angle) * 2,
          (Math.random() - 0.5) * 2,
          Math.sin(angle) * 2
        );
        mito.rotation.set(Math.random(), Math.random(), Math.random());
        mito.name = '미토콘드리아';
        mito.userData.info = '세포 호흡을 통해 ATP(에너지)를 생성하는 세포의 발전소입니다.';
        group.add(mito);
      }

      // Endoplasmic Reticulum (rough)
      const erGroup = new THREE.Group();
      erGroup.name = '소포체';
      for (let i = 0; i < 8; i++) {
        const erGeo = new THREE.TorusGeometry(0.3, 0.05, 8, 16);
        const erMat = new THREE.MeshStandardMaterial({
          color: 0x3b82f6
        });
        const er = new THREE.Mesh(erGeo, erMat);
        er.position.set(
          1.5 + Math.random() * 0.5,
          -1 + i * 0.25,
          0.5
        );
        er.rotation.y = Math.PI / 2;
        er.userData.info = '단백질 합성과 운반에 관여합니다.';
        erGroup.add(er);
      }
      group.add(erGroup);

      // Golgi apparatus
      const golgiGroup = new THREE.Group();
      golgiGroup.name = '골지체';
      for (let i = 0; i < 4; i++) {
        const golgiGeo = new THREE.TorusGeometry(0.5 - i * 0.08, 0.06, 8, 32, Math.PI);
        const golgiMat = new THREE.MeshStandardMaterial({
          color: 0x22c55e
        });
        const golgi = new THREE.Mesh(golgiGeo, golgiMat);
        golgi.position.set(-1.5, i * 0.15 - 0.3, 1);
        golgi.userData.info = '단백질을 가공하고 분비하는 역할을 합니다.';
        golgiGroup.add(golgi);
      }
      group.add(golgiGroup);

      // Ribosomes (small dots)
      for (let i = 0; i < 20; i++) {
        const riboGeo = new THREE.SphereGeometry(0.05, 8, 8);
        const riboMat = new THREE.MeshStandardMaterial({
          color: 0xf97316
        });
        const ribo = new THREE.Mesh(riboGeo, riboMat);
        const theta = Math.random() * Math.PI * 2;
        const phi = Math.random() * Math.PI;
        const r = 1.5 + Math.random() * 1;
        ribo.position.set(
          r * Math.sin(phi) * Math.cos(theta),
          r * Math.sin(phi) * Math.sin(theta),
          r * Math.cos(phi)
        );
        ribo.name = '리보솜';
        ribo.userData.info = 'mRNA를 읽어 단백질을 합성합니다.';
        group.add(ribo);
      }

      group.position.y = 3;
      scene.add(group);

      return { objects: [group], mainObject: group };
    },

    getOrganelles: () => [
      { name: '세포막', color: '#fcd34d' },
      { name: '핵', color: '#7c3aed' },
      { name: '미토콘드리아', color: '#ef4444' },
      { name: '소포체', color: '#3b82f6' },
      { name: '골지체', color: '#22c55e' },
      { name: '리보솜', color: '#f97316' }
    ]
  },

  // DNA Structure
  dnaStructure: {
    id: 'dna-structure',
    name: 'DNA 구조',
    subject: 'biology',
    topic: 'genetics',
    description: 'DNA 이중나선 구조와 염기쌍을 학습합니다.',
    concepts: ['이중나선', '염기쌍', 'A-T', 'G-C', '뉴클레오타이드'],

    setup: (scene, physics, THREE) => {
      const group = new THREE.Group();
      group.name = 'DNA';

      const basePairColors = {
        AT: [0xef4444, 0x22c55e], // Adenine-Thymine
        GC: [0x3b82f6, 0xf59e0b]  // Guanine-Cytosine
      };

      const turns = 3;
      const pointsPerTurn = 20;
      const totalPoints = turns * pointsPerTurn;
      const radius = 1;
      const height = 8;

      for (let i = 0; i < totalPoints; i++) {
        const t = i / totalPoints;
        const angle = t * Math.PI * 2 * turns;
        const y = t * height - height / 2;

        // Strand 1 backbone
        const backbone1Geo = new THREE.SphereGeometry(0.1, 8, 8);
        const backbone1Mat = new THREE.MeshStandardMaterial({ color: 0x64748b });
        const backbone1 = new THREE.Mesh(backbone1Geo, backbone1Mat);
        backbone1.position.set(
          Math.cos(angle) * radius,
          y,
          Math.sin(angle) * radius
        );
        group.add(backbone1);

        // Strand 2 backbone (opposite)
        const backbone2 = backbone1.clone();
        backbone2.position.set(
          Math.cos(angle + Math.PI) * radius,
          y,
          Math.sin(angle + Math.PI) * radius
        );
        group.add(backbone2);

        // Base pairs (every other point)
        if (i % 2 === 0) {
          const pairType = Math.random() > 0.5 ? 'AT' : 'GC';
          const colors = basePairColors[pairType];

          // Base 1
          const base1Geo = new THREE.CylinderGeometry(0.08, 0.08, radius * 0.8, 8);
          const base1Mat = new THREE.MeshStandardMaterial({ color: colors[0] });
          const base1 = new THREE.Mesh(base1Geo, base1Mat);
          base1.position.set(
            Math.cos(angle) * radius * 0.6,
            y,
            Math.sin(angle) * radius * 0.6
          );
          base1.rotation.z = Math.PI / 2;
          base1.rotation.y = angle;
          base1.name = pairType[0];
          group.add(base1);

          // Base 2
          const base2Geo = new THREE.CylinderGeometry(0.08, 0.08, radius * 0.8, 8);
          const base2Mat = new THREE.MeshStandardMaterial({ color: colors[1] });
          const base2 = new THREE.Mesh(base2Geo, base2Mat);
          base2.position.set(
            Math.cos(angle + Math.PI) * radius * 0.6,
            y,
            Math.sin(angle + Math.PI) * radius * 0.6
          );
          base2.rotation.z = Math.PI / 2;
          base2.rotation.y = angle + Math.PI;
          base2.name = pairType[1];
          group.add(base2);
        }
      }

      group.position.y = 4;
      scene.add(group);

      // Animation data
      group.userData.animate = (delta) => {
        group.rotation.y += delta * 0.5;
      };

      return { objects: [group], mainObject: group };
    },

    getBasePairs: () => [
      { pair: 'A-T', colors: ['#ef4444', '#22c55e'], description: '아데닌-티민 (2개 수소결합)' },
      { pair: 'G-C', colors: ['#3b82f6', '#f59e0b'], description: '구아닌-시토신 (3개 수소결합)' }
    ]
  }
};

// Get all biology lessons
export function getAllBiologyLessons() {
  return Object.values(BiologyLessons);
}

// Get lesson by ID
export function getBiologyLessonById(id) {
  return Object.values(BiologyLessons).find(lesson => lesson.id === id);
}
