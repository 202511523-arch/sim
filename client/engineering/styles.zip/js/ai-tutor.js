/**
 * AI Tutor Module - Gemini API Integration
 * Provides AI-powered tutoring for science learning
 */

export class AITutor {
  constructor() {
    this.apiKey = null;
    this.apiUrl = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent';
    this.conversationHistory = [];
    this.currentContext = null;
    this.isConfigured = false;

    // Load API key from localStorage if available
    this.loadApiKey();
  }

  /**
   * Load API key from localStorage
   */
  loadApiKey() {
    const savedKey = localStorage.getItem('gemini_api_key');
    if (savedKey) {
      this.apiKey = savedKey;
      this.isConfigured = true;
    }
  }

  /**
   * Save API key to localStorage
   */
  setApiKey(key) {
    this.apiKey = key;
    localStorage.setItem('gemini_api_key', key);
    this.isConfigured = true;
  }

  /**
   * Clear API key
   */
  clearApiKey() {
    this.apiKey = null;
    localStorage.removeItem('gemini_api_key');
    this.isConfigured = false;
  }

  /**
   * Check if API is configured
   */
  checkConfiguration() {
    return this.isConfigured && this.apiKey;
  }

  /**
   * Set current learning context
   */
  setContext(context) {
    this.currentContext = context;
  }

  /**
   * Build system prompt based on current context
   */
  buildSystemPrompt() {
    let systemPrompt = `당신은 과학 교육 전문 AI 튜터입니다. 학생들에게 물리학, 생명과학, 화학을 친절하고 이해하기 쉽게 설명해주세요.

주요 역할:
- 과학 개념을 명확하게 설명
- 현재 진행 중인 실험/시뮬레이션에 대한 설명 제공
- 질문에 대한 단계별 답변
- 학습을 돕는 힌트와 예시 제공

응답 규칙:
- 한국어로 응답
- 간결하지만 완전한 설명
- 수식이 필요한 경우 텍스트로 표현
- 실생활 예시 활용`;

    if (this.currentContext) {
      systemPrompt += `\n\n현재 학습 컨텍스트:\n- 주제: ${this.currentContext.topic || '일반 과학'}\n- 실험: ${this.currentContext.experiment || '없음'}\n- 분야: ${this.currentContext.subject || '과학'}`;
    }

    return systemPrompt;
  }

  /**
   * Send message to AI and get response
   */
  async sendMessage(message) {
    if (!this.checkConfiguration()) {
      return {
        success: false,
        error: 'API 키가 설정되지 않았습니다. 설정에서 Gemini API 키를 입력해주세요.'
      };
    }

    // Add user message to history
    this.conversationHistory.push({
      role: 'user',
      parts: [{ text: message }]
    });

    try {
      const response = await fetch(`${this.apiUrl}?key=${this.apiKey}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          contents: [
            {
              role: 'user',
              parts: [{ text: this.buildSystemPrompt() }]
            },
            ...this.conversationHistory
          ],
          generationConfig: {
            temperature: 0.7,
            topK: 40,
            topP: 0.95,
            maxOutputTokens: 1024
          }
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error?.message || 'API 요청 실패');
      }

      const data = await response.json();
      const aiResponse = data.candidates?.[0]?.content?.parts?.[0]?.text || '응답을 받지 못했습니다.';

      // Add AI response to history
      this.conversationHistory.push({
        role: 'model',
        parts: [{ text: aiResponse }]
      });

      return {
        success: true,
        message: aiResponse
      };

    } catch (error) {
      console.error('AI Tutor error:', error);
      return {
        success: false,
        error: error.message || '알 수 없는 오류가 발생했습니다.'
      };
    }
  }

  /**
   * Get explanation for current experiment
   */
  async explainExperiment(experimentName, experimentData = {}) {
    const prompt = `현재 "${experimentName}" 실험을 진행하고 있습니다.
        
실험 데이터:
${JSON.stringify(experimentData, null, 2)}

이 실험의 과학적 원리와 관찰할 수 있는 현상에 대해 설명해주세요.`;

    return await this.sendMessage(prompt);
  }

  /**
   * Get learning hints
   */
  async getHint(topic) {
    const prompt = `"${topic}"에 대해 이해하는 데 도움이 될 힌트나 팁을 알려주세요.`;
    return await this.sendMessage(prompt);
  }

  /**
   * Clear conversation history
   */
  clearHistory() {
    this.conversationHistory = [];
  }

  /**
   * Get quick explanations for physics concepts
   */
  getQuickExplanation(concept) {
    const explanations = {
      'gravity': {
        title: '중력 (Gravity)',
        formula: 'F = G × (m₁ × m₂) / r²',
        description: '모든 물체는 질량에 비례하는 중력으로 서로 끌어당깁니다.',
        realWorld: '사과가 땅으로 떨어지는 이유, 달이 지구 주위를 도는 이유'
      },
      'momentum': {
        title: '운동량 (Momentum)',
        formula: 'p = m × v',
        description: '물체의 질량과 속도의 곱으로, 운동의 양을 나타냅니다.',
        realWorld: '당구공 충돌, 로켓 추진'
      },
      'energy': {
        title: '에너지 보존 법칙',
        formula: 'E_total = E_kinetic + E_potential',
        description: '에너지는 형태가 바뀔 수 있지만 총량은 보존됩니다.',
        realWorld: '롤러코스터, 진자 시계'
      },
      'friction': {
        title: '마찰력 (Friction)',
        formula: 'f = μ × N',
        description: '물체의 운동을 방해하는 힘으로, 접촉면의 성질에 따라 달라집니다.',
        realWorld: '자동차 브레이크, 걷기'
      }
    };

    return explanations[concept] || null;
  }
}

// Science subjects and topics
export const ScienceTopics = {
  physics: {
    name: '물리학',
    icon: '⚡',
    topics: [
      { id: 'mechanics', name: '역학', subtopics: ['자유낙하', '진자운동', '충돌', '경사면'] },
      { id: 'waves', name: '파동', subtopics: ['음파', '빛', '간섭'] },
      { id: 'thermodynamics', name: '열역학', subtopics: ['열전달', '기체법칙'] },
      { id: 'electromagnetism', name: '전자기학', subtopics: ['전기장', '자기장', '전자기유도'] }
    ]
  },
  biology: {
    name: '생명과학',
    icon: '🧬',
    topics: [
      { id: 'cell', name: '세포', subtopics: ['세포구조', '세포분열', '광합성'] },
      { id: 'genetics', name: '유전', subtopics: ['DNA구조', '유전법칙', '돌연변이'] },
      { id: 'anatomy', name: '해부학', subtopics: ['순환계', '신경계', '소화계'] },
      { id: 'ecology', name: '생태학', subtopics: ['먹이사슬', '생태계'] }
    ]
  },
  chemistry: {
    name: '화학',
    icon: '⚗️',
    topics: [
      { id: 'atomic', name: '원자', subtopics: ['원자구조', '전자배치', '주기율표'] },
      { id: 'molecular', name: '분자', subtopics: ['화학결합', '분자구조', '극성'] },
      { id: 'reactions', name: '반응', subtopics: ['산화환원', '산염기', '반응속도'] }
    ]
  }
};
