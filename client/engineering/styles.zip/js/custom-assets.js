/**
 * Custom 3D Assets Configuration
 * Map lesson parts to your custom GLB/GLTF/OBJ files here.
 * Path is relative to the project root.
 */

export const CustomAssets = {
  // 6-DOF Robot Arm
  robotArm: {
    // Strategy: Try using global origin (0,0,0) for all parts. 
    // If these files were exported from a single CAD assembly, 
    // they usually retain their relative positions if placed at the world origin.

    // 1. Base
    base: {
      url: '3D Asset/Robot Arm/base.glb',
      scale: 5.0,
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 }
    },
    // 2. Shoulder
    shoulder: {
      url: '3D Asset/Robot Arm/Part2.glb',
      scale: 5.0,
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 }
    },
    // 3. Upper Arm
    upperArm: {
      url: '3D Asset/Robot Arm/Part3.glb',
      scale: 5.0,
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 }
    },
    // 4. Elbow
    elbow: {
      url: '3D Asset/Robot Arm/Part4.glb',
      scale: 5.0,
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 }
    },
    // 5. Forearm
    forearm: {
      url: '3D Asset/Robot Arm/Part5.glb',
      scale: 5.0,
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 }
    },
    // 6. Wrist
    wrist: {
      url: '3D Asset/Robot Arm/Part6.glb',
      scale: 5.0,
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 }
    },
    // 7. End Effector / Gripper
    endEffector: {
      url: '3D Asset/Robot Arm/Part7.glb',
      scale: 5.0,
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 }
    }
  },

  // Racing Drone
  drone: {
    frame: {
      url: '3D Asset/Drone/Main frame.glb',
      scale: 5.0,
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 }
    },
    // Map other parts as needed
    // topPlate: { url: ... },
    // battery: { url: ... },
  }
};
