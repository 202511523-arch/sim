/**
 * 3D Studio Pro - Main Application
 * Web-based 3D Model Viewer with Blender/CAD features
 */

import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { TransformControls } from 'three/addons/controls/TransformControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';
import { STLLoader } from 'three/addons/loaders/STLLoader.js';
import { FBXLoader } from 'three/addons/loaders/FBXLoader.js';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import { OBJExporter } from 'three/addons/exporters/OBJExporter.js';
import { STLExporter } from 'three/addons/exporters/STLExporter.js';

// Post-processing
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { OutlinePass } from 'three/addons/postprocessing/OutlinePass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';

import { PhysicsEngine } from './js/physics.js';
import { AITutor } from './js/ai-tutor.js';
import { PhysicsLessons } from './js/lessons/physics-lessons.js';
import { BiologyLessons } from './js/lessons/biology-lessons.js';
import { ChemistryLessons } from './js/lessons/chemistry-lessons.js';
import { EngineeringLessons } from './js/lessons/engineering-lessons.js';
import { RoboticsLessons } from './js/lessons/robotics-lessons.js';

// ============================================
// App State
// ============================================
const state = {
  currentTool: 'select',
  viewMode: 'solid',
  selectedObject: null,
  objects: [],
  measurePoints: [],
  isMeasuring: false,
  history: { undo: [], redo: [] }
};

// ============================================
// Scene Setup
// ============================================
let scene, camera, renderer, controls, transformControls;
let raycaster, mouse;
let gridHelper, axesHelper;
let ambientLight, directionalLight;
let stats = { objects: 0, triangles: 0 };
let physics, aiTutor;
let composer, outlinePass;

function initScene() {
  const canvas = document.getElementById('viewport');
  const container = document.getElementById('viewport-container');

  // Scene
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x0a0a0f);
  scene.fog = new THREE.Fog(0x0a0a0f, 50, 200);

  // Camera
  camera = new THREE.PerspectiveCamera(
    60,
    container.clientWidth / container.clientHeight,
    0.1,
    1000
  );
  camera.position.set(8, 6, 8);
  camera.lookAt(0, 0, 0);

  // Renderer
  renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    alpha: true
  });
  renderer.setSize(container.clientWidth, container.clientHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.2;

  // Controls
  controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.08;
  controls.minDistance = 1;
  controls.maxDistance = 100;
  controls.target.set(0, 0, 0);

  // Transform Controls
  // Transform Controls
  transformControls = new TransformControls(camera, renderer.domElement);

  let dragStartTransform = null;

  transformControls.addEventListener('dragging-changed', (e) => {
    controls.enabled = !e.value;

    // Undo/Redo Logic
    if (state.selectedObject) {
      if (e.value) { // Drag Start
        // Capture state before change
        dragStartTransform = {
          position: state.selectedObject.position.clone(),
          rotation: state.selectedObject.rotation.clone(),
          scale: state.selectedObject.scale.clone()
        };
      } else { // Drag End
        if (dragStartTransform) {
          // Capture state after change
          const dragEndTransform = {
            position: state.selectedObject.position.clone(),
            rotation: state.selectedObject.rotation.clone(),
            scale: state.selectedObject.scale.clone()
          };

          // Push to history
          addToHistory({
            type: 'transform',
            objectUuid: state.selectedObject.uuid,
            before: dragStartTransform,
            after: dragEndTransform
          });

          // Log for calibration
          logCalibrationData(state.selectedObject);

          dragStartTransform = null;
        }
      }
    }
  });

  transformControls.addEventListener('change', () => {
    if (state.selectedObject) {
      updatePropertiesPanel();
    }
  });
  scene.add(transformControls);

  // Raycaster
  raycaster = new THREE.Raycaster();
  mouse = new THREE.Vector2();

  // Grid
  gridHelper = new THREE.GridHelper(20, 20, 0x3f3f5f, 0x1a1a24);
  gridHelper.material.opacity = 0.6;
  gridHelper.material.transparent = true;
  scene.add(gridHelper);

  // Axes Helper
  axesHelper = new THREE.AxesHelper(2);
  scene.add(axesHelper);

  // Lighting
  ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
  scene.add(ambientLight);

  directionalLight = new THREE.DirectionalLight(0xffffff, 1);
  directionalLight.position.set(10, 20, 10);
  directionalLight.castShadow = true;
  directionalLight.shadow.mapSize.width = 2048;
  directionalLight.shadow.mapSize.height = 2048;
  directionalLight.shadow.camera.near = 0.5;
  directionalLight.shadow.camera.far = 50;
  directionalLight.shadow.camera.left = -15;
  directionalLight.shadow.camera.right = 15;
  directionalLight.shadow.camera.top = 15;
  directionalLight.shadow.camera.bottom = -15;
  scene.add(directionalLight);

  // Hemisphere Light for ambient
  const hemiLight = new THREE.HemisphereLight(0x7c3aed, 0x06b6d4, 0.3);
  scene.add(hemiLight);

  // Ground plane (shadow receiver)
  const groundGeo = new THREE.PlaneGeometry(100, 100);
  const groundMat = new THREE.ShadowMaterial({ opacity: 0.3 });
  const ground = new THREE.Mesh(groundGeo, groundMat);
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  ground.userData.isGround = true;
  scene.add(ground);

  // Handle resize
  window.addEventListener('resize', onWindowResize);

  // Post-processing Setup
  composer = new EffectComposer(renderer);

  const renderPass = new RenderPass(scene, camera);
  composer.addPass(renderPass);

  outlinePass = new OutlinePass(new THREE.Vector2(window.innerWidth, window.innerHeight), scene, camera);
  outlinePass.edgeStrength = 4.0;
  outlinePass.edgeGlow = 0.5;
  outlinePass.edgeThickness = 1.0;
  outlinePass.pulsePeriod = 0;
  outlinePass.visibleEdgeColor.set('#fcfc00'); // Yellow outline
  outlinePass.hiddenEdgeColor.set('#190a05');
  composer.addPass(outlinePass);

  const outputPass = new OutputPass();
  composer.addPass(outputPass);

  // Physics & AI Setup
  physics = new PhysicsEngine();
  aiTutor = new AITutor();

  setStatus('3D Studio Pro 준비됨');
}

function onWindowResize() {
  const container = document.getElementById('viewport-container');
  camera.aspect = container.clientWidth / container.clientHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(container.clientWidth, container.clientHeight);
  if (composer) composer.setSize(container.clientWidth, container.clientHeight);
}

// ============================================
// Animation Loop
// ============================================
let lastTime = performance.now();
let frameCount = 0;
let fps = 60;

function animate() {
  requestAnimationFrame(animate);

  // FPS counter
  frameCount++;
  const currentTime = performance.now();
  if (currentTime - lastTime >= 1000) {
    fps = frameCount;
    document.getElementById('fps-counter').textContent = `${fps} FPS`;
    frameCount = 0;
    lastTime = currentTime;
  }

  // Update controls
  controls.update();

  // Update stats
  updateStats();

  // Physics Update
  if (physics && physics.isRunning) {
    physics.update(1 / 60);

    // Update lesson info if active
    if (learningState.currentLesson && learningState.currentSubject === 'physics') {
      updateLessonInfo();
    }
  }

  // Lesson-specific Update (for robotics explode animation, circuit updates, etc.)
  if (learningState.currentLessonModule && learningState.currentLessonModule.onUpdate && learningState.lessonObjects.length > 0) {
    learningState.currentLessonModule.onUpdate(learningState.lessonObjects, 1 / 60);
  }

  // Render
  if (composer) {
    composer.render();
  } else {
    renderer.render(scene, camera);
  }
}

function updateStats() {
  let triangles = 0;
  let objects = 0;

  scene.traverse((obj) => {
    if (obj.isMesh && !obj.userData.isGround && !obj.userData.isHelper) {
      objects++;
      if (obj.geometry) {
        const geo = obj.geometry;
        if (geo.index) {
          triangles += geo.index.count / 3;
        } else if (geo.attributes.position) {
          triangles += geo.attributes.position.count / 3;
        }
      }
    }
  });

  document.getElementById('stats-objects').textContent = `오브젝트: ${objects}`;
  document.getElementById('stats-triangles').textContent = `삼각형: ${Math.floor(triangles).toLocaleString()}`;
}

// ============================================
// Object Management
// ============================================
function addPrimitive(type) {
  let geometry, mesh;
  const material = new THREE.MeshStandardMaterial({
    color: 0x6366f1,
    metalness: 0,
    roughness: 0.5
  });

  switch (type) {
    case 'cube':
      geometry = new THREE.BoxGeometry(1, 1, 1);
      break;
    case 'sphere':
      geometry = new THREE.SphereGeometry(0.5, 32, 32);
      break;
    case 'cylinder':
      geometry = new THREE.CylinderGeometry(0.5, 0.5, 1, 32);
      break;
    case 'cone':
      geometry = new THREE.ConeGeometry(0.5, 1, 32);
      break;
    case 'torus':
      geometry = new THREE.TorusGeometry(0.4, 0.15, 16, 48);
      break;
    case 'plane':
      geometry = new THREE.PlaneGeometry(2, 2);
      material.side = THREE.DoubleSide;
      break;
    default:
      return;
  }

  mesh = new THREE.Mesh(geometry, material);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  mesh.name = `${type.charAt(0).toUpperCase() + type.slice(1)}_${state.objects.length + 1}`;
  mesh.position.y = type === 'plane' ? 0.01 : 0.5;

  if (type === 'plane') {
    mesh.rotation.x = -Math.PI / 2;
  }

  scene.add(mesh);
  state.objects.push(mesh);

  updateHierarchy();
  selectObject(mesh);

  setStatus(`${mesh.name} 추가됨`);
}

function selectObject(obj) {
  // Deselect previous
  if (state.selectedObject) {
    const prevItem = document.querySelector(`.hierarchy-item[data-uuid="${state.selectedObject.uuid}"]`);
    if (prevItem) prevItem.classList.remove('selected');
  }

  state.selectedObject = obj;

  if (obj) {
    // Update hierarchy selection
    const item = document.querySelector(`.hierarchy-item[data-uuid="${obj.uuid}"]`);
    if (item) item.classList.add('selected');

    // Attach transform controls
    if (state.currentTool !== 'select' && state.currentTool !== 'measure') {
      transformControls.attach(obj);
    }

    // Outline
    if (outlinePass) outlinePass.selectedObjects = [obj];

    updatePropertiesPanel();
    document.getElementById('obj-name').disabled = false;
  } else {
    transformControls.detach();
    if (outlinePass) outlinePass.selectedObjects = [];
    resetPropertiesPanel();
    document.getElementById('obj-name').disabled = true;
  }
}

function deleteSelectedObject() {
  if (!state.selectedObject) return;

  const obj = state.selectedObject;
  transformControls.detach();
  scene.remove(obj);

  const index = state.objects.indexOf(obj);
  if (index > -1) {
    state.objects.splice(index, 1);
  }

  state.selectedObject = null;
  updateHierarchy();
  resetPropertiesPanel();
  setStatus(`${obj.name} 삭제됨`);
}

// ============================================
// UI Updates
// ============================================
function updateHierarchy() {
  const tree = document.getElementById('hierarchy-tree');

  let html = `
        <div class="hierarchy-item scene-root">
            <span class="material-icons-round">public</span>
            <span class="hierarchy-name">Scene</span>
        </div>
    `;

  state.objects.forEach((obj) => {
    const selected = state.selectedObject === obj ? 'selected' : '';
    html += `
            <div class="hierarchy-item ${selected}" data-uuid="${obj.uuid}">
                <span class="material-icons-round">category</span>
                <span class="hierarchy-name">${obj.name}</span>
            </div>
        `;
  });

  tree.innerHTML = html;

  // Add click handlers
  document.querySelectorAll('.hierarchy-item[data-uuid]').forEach(item => {
    item.addEventListener('click', () => {
      const uuid = item.dataset.uuid;
      const obj = state.objects.find(o => o.uuid === uuid);
      if (obj) selectObject(obj);
    });
  });
}

function updatePropertiesPanel() {
  const obj = state.selectedObject;
  if (!obj) return;

  // Name
  document.getElementById('obj-name').value = obj.name;

  // Geometry info
  if (obj.geometry) {
    const geo = obj.geometry;
    const vertices = geo.attributes.position ? geo.attributes.position.count : 0;
    const faces = geo.index ? geo.index.count / 3 : vertices / 3;
    document.getElementById('obj-vertices').textContent = vertices;
    document.getElementById('obj-faces').textContent = Math.floor(faces);
  }

  // Position
  document.getElementById('pos-x').value = obj.position.x.toFixed(2);
  document.getElementById('pos-y').value = obj.position.y.toFixed(2);
  document.getElementById('pos-z').value = obj.position.z.toFixed(2);

  // Rotation (in degrees)
  document.getElementById('rot-x').value = THREE.MathUtils.radToDeg(obj.rotation.x).toFixed(1);
  document.getElementById('rot-y').value = THREE.MathUtils.radToDeg(obj.rotation.y).toFixed(1);
  document.getElementById('rot-z').value = THREE.MathUtils.radToDeg(obj.rotation.z).toFixed(1);

  // Scale
  document.getElementById('scale-x').value = obj.scale.x.toFixed(2);
  document.getElementById('scale-y').value = obj.scale.y.toFixed(2);
  document.getElementById('scale-z').value = obj.scale.z.toFixed(2);

  // Material
  if (obj.material) {
    const mat = obj.material;
    if (mat.color) {
      document.getElementById('mat-color').value = '#' + mat.color.getHexString();
    }
    document.getElementById('mat-metalness').value = mat.metalness || 0;
    document.querySelector('#mat-metalness + .slider-value').textContent =
      (mat.metalness || 0).toFixed(2);
    document.getElementById('mat-roughness').value = mat.roughness || 0.5;
    document.querySelector('#mat-roughness + .slider-value').textContent =
      (mat.roughness || 0.5).toFixed(2);
  }
}

function resetPropertiesPanel() {
  document.getElementById('obj-name').value = '선택 없음';
  document.getElementById('obj-vertices').textContent = '-';
  document.getElementById('obj-faces').textContent = '-';

  ['pos-x', 'pos-y', 'pos-z'].forEach(id => {
    document.getElementById(id).value = 0;
  });
  ['rot-x', 'rot-y', 'rot-z'].forEach(id => {
    document.getElementById(id).value = 0;
  });
  ['scale-x', 'scale-y', 'scale-z'].forEach(id => {
    document.getElementById(id).value = 1;
  });
}

function setStatus(message) {
  document.getElementById('status-message').textContent = message;
}

// ============================================
// Tool Management
// ============================================
function setTool(tool) {
  state.currentTool = tool;

  // Update UI
  document.querySelectorAll('.tool-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tool === tool);
  });

  // Update transform controls
  if (state.selectedObject) {
    switch (tool) {
      case 'move':
        transformControls.setMode('translate');
        transformControls.attach(state.selectedObject);
        break;
      case 'rotate':
        transformControls.setMode('rotate');
        transformControls.attach(state.selectedObject);
        break;
      case 'scale':
        transformControls.setMode('scale');
        transformControls.attach(state.selectedObject);
        break;
      default:
        transformControls.detach();
    }
  } else {
    transformControls.detach();
  }

  // Measure tool state
  if (tool === 'measure') {
    state.isMeasuring = true;
    state.measurePoints = [];
    setStatus('측정할 첫 번째 지점을 클릭하세요');
  } else {
    state.isMeasuring = false;
    document.getElementById('measurement-display').classList.add('hidden');
  }
}

function setViewMode(mode) {
  state.viewMode = mode;

  document.querySelectorAll('.view-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.mode === mode);
  });

  state.objects.forEach(obj => {
    if (obj.material) {
      switch (mode) {
        case 'wireframe':
          obj.material.wireframe = true;
          break;
        case 'solid':
          obj.material.wireframe = false;
          break;
        case 'textured':
          obj.material.wireframe = false;
          break;
      }
    }
  });
}

// ============================================
// Camera Presets
// ============================================
function setViewPreset(view) {
  const distance = 10;
  const target = controls.target.clone();

  switch (view) {
    case 'front':
      camera.position.set(target.x, target.y, target.z + distance);
      break;
    case 'back':
      camera.position.set(target.x, target.y, target.z - distance);
      break;
    case 'left':
      camera.position.set(target.x - distance, target.y, target.z);
      break;
    case 'right':
      camera.position.set(target.x + distance, target.y, target.z);
      break;
    case 'top':
      camera.position.set(target.x, target.y + distance, target.z + 0.001);
      break;
    case 'bottom':
      camera.position.set(target.x, target.y - distance, target.z + 0.001);
      break;
  }

  camera.lookAt(target);
}

// ============================================
// File Loaders
// ============================================
const loaders = {
  gltf: new GLTFLoader(),
  glb: new GLTFLoader(),
  obj: new OBJLoader(),
  stl: new STLLoader(),
  fbx: new FBXLoader()
};

async function loadModel(file) {
  const extension = file.name.split('.').pop().toLowerCase();
  const url = URL.createObjectURL(file);

  setStatus(`${file.name} 로딩 중...`);

  try {
    let model;

    switch (extension) {
      case 'gltf':
      case 'glb':
        const gltf = await loaders.gltf.loadAsync(url);
        model = gltf.scene;
        break;
      case 'obj':
        model = await loaders.obj.loadAsync(url);
        break;
      case 'stl':
        const geometry = await loaders.stl.loadAsync(url);
        const material = new THREE.MeshStandardMaterial({
          color: 0x6366f1,
          metalness: 0.2,
          roughness: 0.6
        });
        model = new THREE.Mesh(geometry, material);
        break;
      case 'fbx':
        model = await loaders.fbx.loadAsync(url);
        break;
      default:
        throw new Error('지원하지 않는 파일 형식입니다.');
    }

    // Normalize model size and position
    const box = new THREE.Box3().setFromObject(model);
    const size = box.getSize(new THREE.Vector3());
    const maxDim = Math.max(size.x, size.y, size.z);
    const scale = 5 / maxDim;
    model.scale.multiplyScalar(scale);

    box.setFromObject(model);
    const center = box.getCenter(new THREE.Vector3());
    model.position.sub(center);
    model.position.y = box.getSize(new THREE.Vector3()).y / 2;

    // Setup shadows
    model.traverse((child) => {
      if (child.isMesh) {
        child.castShadow = true;
        child.receiveShadow = true;
      }
    });

    model.name = file.name.replace(/\.[^/.]+$/, '');
    scene.add(model);
    state.objects.push(model);

    updateHierarchy();
    selectObject(model);

    // Focus camera on model
    const modelBox = new THREE.Box3().setFromObject(model);
    const modelCenter = modelBox.getCenter(new THREE.Vector3());
    controls.target.copy(modelCenter);

    setStatus(`${file.name} 로드 완료`);

  } catch (error) {
    console.error('Load error:', error);
    setStatus(`로드 실패: ${error.message}`);
  }

  URL.revokeObjectURL(url);
}

// ============================================
// Exporters
// ============================================
function exportScene(format) {
  const exportGroup = new THREE.Group();
  state.objects.forEach(obj => {
    exportGroup.add(obj.clone());
  });

  let exporter, data, blob, ext;

  switch (format) {
    case 'gltf':
    case 'glb':
      exporter = new GLTFExporter();
      const binary = format === 'glb';
      exporter.parse(exportGroup, (result) => {
        if (binary) {
          blob = new Blob([result], { type: 'application/octet-stream' });
        } else {
          blob = new Blob([JSON.stringify(result)], { type: 'application/json' });
        }
        downloadBlob(blob, `scene.${format}`);
      }, { binary });
      return;
    case 'obj':
      exporter = new OBJExporter();
      data = exporter.parse(exportGroup);
      blob = new Blob([data], { type: 'text/plain' });
      ext = 'obj';
      break;
    case 'stl':
      exporter = new STLExporter();
      data = exporter.parse(exportGroup, { binary: true });
      blob = new Blob([data], { type: 'application/octet-stream' });
      ext = 'stl';
      break;
    default:
      return;
  }

  downloadBlob(blob, `scene.${ext}`);
  closeModal('export-modal');
  setStatus(`scene.${ext} 내보내기 완료`);
}

function downloadBlob(blob, filename) {
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.click();
  URL.revokeObjectURL(link.href);
}

function captureScreenshot() {
  renderer.render(scene, camera);
  const dataURL = renderer.domElement.toDataURL('image/png');
  const link = document.createElement('a');
  link.href = dataURL;
  link.download = 'screenshot.png';
  link.click();
  setStatus('스크린샷 저장됨');
}

// ============================================
// Measurement Tool
// ============================================
let measureLine = null;
let measureSpheres = [];

function handleMeasureClick(event) {
  if (!state.isMeasuring) return;

  const rect = renderer.domElement.getBoundingClientRect();
  mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
  mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

  raycaster.setFromCamera(mouse, camera);

  const objects = state.objects.filter(o => o.isMesh || o.isGroup);
  const intersects = raycaster.intersectObjects(objects, true);

  if (intersects.length > 0) {
    const point = intersects[0].point.clone();
    state.measurePoints.push(point);

    // Add visual marker
    const sphereGeo = new THREE.SphereGeometry(0.05);
    const sphereMat = new THREE.MeshBasicMaterial({ color: 0x06b6d4 });
    const sphere = new THREE.Mesh(sphereGeo, sphereMat);
    sphere.position.copy(point);
    sphere.userData.isHelper = true;
    scene.add(sphere);
    measureSpheres.push(sphere);

    if (state.measurePoints.length === 2) {
      // Draw line
      const points = state.measurePoints;
      const lineGeo = new THREE.BufferGeometry().setFromPoints(points);
      const lineMat = new THREE.LineBasicMaterial({ color: 0x06b6d4, linewidth: 2 });
      measureLine = new THREE.Line(lineGeo, lineMat);
      measureLine.userData.isHelper = true;
      scene.add(measureLine);

      // Calculate distance
      const distance = points[0].distanceTo(points[1]);
      document.getElementById('measure-distance').textContent = distance.toFixed(3);
      document.getElementById('measurement-display').classList.remove('hidden');

      setStatus(`거리: ${distance.toFixed(3)} units`);

      // Reset for next measurement
      state.measurePoints = [];
    } else {
      setStatus('측정할 두 번째 지점을 클릭하세요');
    }
  }
}

function clearMeasurements() {
  if (measureLine) {
    scene.remove(measureLine);
    measureLine = null;
  }
  measureSpheres.forEach(s => scene.remove(s));
  measureSpheres = [];
  state.measurePoints = [];
  document.getElementById('measurement-display').classList.add('hidden');
}

// ============================================
// Mouse Handlers
// ============================================
function onMouseClick(event) {
  if (state.isMeasuring) {
    handleMeasureClick(event);
    return;
  }

  // Skip if clicking on transform controls
  if (transformControls.dragging) return;

  const rect = renderer.domElement.getBoundingClientRect();
  mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
  mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

  raycaster.setFromCamera(mouse, camera);

  const objects = state.objects.filter(o => o.isMesh || o.isGroup);
  const intersects = raycaster.intersectObjects(objects, true);

  if (intersects.length > 0) {
    let obj = intersects[0].object;
    // Find parent if it's part of a group, unless it's explicitly selectable
    while (obj.parent && !state.objects.includes(obj) && !obj.userData.isSelectable) {
      obj = obj.parent;
    }

    // Logic: If obj is selectable (part), but its parent (group) is NOT exploded,
    // we should select the parent instead.
    if (obj.userData.isSelectable && obj.parent &&
      state.objects.includes(obj.parent) &&
      obj.parent.userData.isExploded === false) {
      obj = obj.parent;
    }

    // If we walked up to the Scene (no parent) and it's not in objects, ignore
    // But if we stopped because it isSelectable, or it is in objects, select it
    if (state.objects.includes(obj) || obj.userData.isSelectable) {
      selectObject(obj);
    }
  } else {
    selectObject(null);
  }
}

function onMouseMove(event) {
  const rect = renderer.domElement.getBoundingClientRect();
  const x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
  const y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

  // Update coordinates display
  raycaster.setFromCamera(new THREE.Vector2(x, y), camera);
  const plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
  const intersection = new THREE.Vector3();
  raycaster.ray.intersectPlane(plane, intersection);

  if (intersection) {
    document.getElementById('coord-x').textContent = intersection.x.toFixed(2);
    document.getElementById('coord-y').textContent = intersection.y.toFixed(2);
    document.getElementById('coord-z').textContent = intersection.z.toFixed(2);
  }
}

// ============================================
// Modal Functions
// ============================================
function openModal(modalId) {
  document.getElementById(modalId).classList.remove('hidden');
}

function closeModal(modalId) {
  document.getElementById(modalId).classList.add('hidden');
}

// ============================================
// Keyboard Shortcuts
// ============================================
function onKeyDown(event) {
  // Ignore if typing in input
  if (event.target.tagName === 'INPUT') return;

  switch (event.key.toLowerCase()) {
    case 'q':
      setTool('select');
      break;
    case 'g':
      setTool('move');
      break;
    case 'r':
      setTool('rotate');
      break;
    case 's':
      if (!event.ctrlKey) setTool('scale');
      break;
    case 'x':
    case 'delete':
      deleteSelectedObject();
      break;
    case 'f':
      if (state.selectedObject) {
        controls.target.copy(state.selectedObject.position);
      }
      break;
    case 'escape':
      selectObject(null);
      if (state.isMeasuring) {
        setTool('select');
        clearMeasurements();
      }
      break;
  }

  // Ctrl shortcuts
  if (event.ctrlKey) {
    switch (event.key.toLowerCase()) {
      case 'n':
        event.preventDefault();
        newScene();
        break;
      case 'o':
        event.preventDefault();
        openModal('import-modal');
        break;
      case 's':
        event.preventDefault();
        openModal('export-modal');
        break;
    }
  }

  // Numpad view presets
  if (event.key.startsWith('Numpad')) {
    switch (event.key) {
      case 'Numpad1':
        setViewPreset('front');
        break;
      case 'Numpad3':
        setViewPreset('right');
        break;
      case 'Numpad7':
        setViewPreset('top');
        break;
    }
  }
}

// ============================================
// Scene Management
// ============================================
function newScene() {
  // Remove all objects
  state.objects.forEach(obj => {
    scene.remove(obj);
  });
  state.objects = [];
  state.selectedObject = null;

  transformControls.detach();
  clearMeasurements();
  updateHierarchy();
  resetPropertiesPanel();

  setStatus('새 씬 생성됨');
}

// ============================================
// Drag & Drop
// ============================================
function setupDragDrop() {
  const viewport = document.getElementById('viewport-container');
  const dropZone = document.getElementById('drop-zone');

  ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
    viewport.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
    });
  });

  viewport.addEventListener('dragenter', () => {
    dropZone.classList.remove('hidden');
  });

  dropZone.addEventListener('dragleave', (e) => {
    if (e.target === dropZone) {
      dropZone.classList.add('hidden');
    }
  });

  dropZone.addEventListener('drop', (e) => {
    dropZone.classList.add('hidden');
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      loadModel(files[0]);
    }
  });
}

// ============================================
// Event Listeners Setup
// ============================================
function setupEventListeners() {
  // Viewport mouse events
  const canvas = renderer.domElement;
  canvas.addEventListener('click', onMouseClick);
  canvas.addEventListener('mousemove', onMouseMove);

  // Keyboard
  window.addEventListener('keydown', onKeyDown);

  // Tool buttons
  document.querySelectorAll('.tool-btn').forEach(btn => {
    btn.addEventListener('click', () => setTool(btn.dataset.tool));
  });

  // View mode buttons
  document.querySelectorAll('.view-btn').forEach(btn => {
    btn.addEventListener('click', () => setViewMode(btn.dataset.mode));
  });

  // View presets
  document.querySelectorAll('.preset-btn').forEach(btn => {
    btn.addEventListener('click', () => setViewPreset(btn.dataset.view));
  });

  // Primitive buttons
  document.querySelectorAll('.primitive-btn').forEach(btn => {
    btn.addEventListener('click', () => addPrimitive(btn.dataset.shape));
  });

  // Toolbar buttons
  document.getElementById('btn-new').addEventListener('click', newScene);
  document.getElementById('btn-open').addEventListener('click', () => openModal('import-modal'));
  document.getElementById('btn-export').addEventListener('click', () => openModal('export-modal'));
  document.getElementById('btn-screenshot').addEventListener('click', captureScreenshot);
  document.getElementById('btn-fullscreen').addEventListener('click', () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
    } else {
      document.exitFullscreen();
    }
  });

  // Property inputs
  setupPropertyInputs();

  // Blender-style Keyboard Shortcuts
  // Blender-style Keyboard Shortcuts & Snapping
  const updateSnapping = (enabled) => {
    if (enabled) {
      transformControls.setTranslationSnap(0.5);
      transformControls.setRotationSnap(Math.PI / 4); // 45 degrees
      transformControls.setScaleSnap(0.1);
    } else {
      transformControls.setTranslationSnap(null);
      transformControls.setRotationSnap(null);
      transformControls.setScaleSnap(null);
    }
  };

  window.addEventListener('keyup', (event) => {
    if (event.key === 'Shift') {
      updateSnapping(false);
      setStatus('자석(Snap) 끄기');
    }
  });

  window.addEventListener('keydown', (event) => {
    // Snapping (Magnet)
    if (event.key === 'Shift' && !event.repeat) {
      updateSnapping(true);
      setStatus('자석(Snap) 켜기 (45도/0.5단위)');
    }

    // Ignore if typing in input fields
    if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') return;

    switch (event.key.toLowerCase()) {
      case 'g': // Grab (Translate)
        if (state.selectedObject) {
          // Use setTool to ensure controls are attached and state is updated
          setTool('move');
          setStatus('이동 모드 (Move)');
        }
        break;
      case 'r': // Rotate
        if (state.selectedObject) {
          setTool('rotate');
          setStatus('회전 모드 (Rotate)');
        }
        break;
      case 's': // Scale
        if (state.selectedObject) {
          // Allow simple S for scale (Blender style), ignoring Ctrl check 
          // (app's original onKeyDown checked !ctrlKey for S, likely to avoid Save conflict if any)
          setTool('scale');
          setStatus('크기 모드 (Scale)');
        }
        break;
      case 'escape': // Cancel/Deselect
        if (transformControls.dragging) {
          transformControls.detach(); // Cancel drag visual
        } else {
          selectObject(null);
          setTool('select'); // Reset tool to select
          setStatus('선택 취소');
        }
        break;
    }
  });

  // Modals
  document.querySelectorAll('.modal-close').forEach(btn => {
    btn.addEventListener('click', () => {
      btn.closest('.modal').classList.add('hidden');
    });
  });

  document.querySelectorAll('.modal').forEach(modal => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.classList.add('hidden');
      }
    });
  });

  // Undo/Redo Shortcuts
  window.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
      e.preventDefault();
      undo();
    }
    if ((e.ctrlKey || e.metaKey) && (e.key.toLowerCase() === 'y' || (e.shiftKey && e.key.toLowerCase() === 'z'))) {
      e.preventDefault();
      redo();
    }
  });

  // Wire Buttons
  document.getElementById('btn-undo')?.addEventListener('click', undo);
  document.getElementById('btn-redo')?.addEventListener('click', redo);

  // File input
  const fileDropArea = document.getElementById('file-drop-area');
  const fileInput = document.getElementById('file-input');

  fileDropArea.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
      loadModel(e.target.files[0]);
      closeModal('import-modal');
    }
  });

  // Export buttons
  document.querySelectorAll('.export-btn').forEach(btn => {
    btn.addEventListener('click', () => exportScene(btn.dataset.format));
  });

  // Drag & Drop
  setupDragDrop();
}

// ============================================
// Undo / Redo System
// ============================================
function addToHistory(action) {
  state.history.undo.push(action);
  state.history.redo = []; // Clear redo stack on new action
  // Limit stack size if needed
  if (state.history.undo.length > 50) state.history.undo.shift();
  console.log('Action added to history:', action);
}

function undo() {
  if (state.history.undo.length === 0) {
    setStatus('실행 취소할 작업이 없습니다.');
    return;
  }

  const action = state.history.undo.pop();
  state.history.redo.push(action);

  applyAction(action, true); // true = inverse (undo)
  setStatus('실행 취소됨');
}

function redo() {
  if (state.history.redo.length === 0) {
    setStatus('다시 실행할 작업이 없습니다.');
    return;
  }

  const action = state.history.redo.pop();
  state.history.undo.push(action);

  applyAction(action, false); // false = normal (redo)
  setStatus('다시 실행됨');
}

function applyAction(action, isUndo) {
  if (action.type === 'transform') {
    const obj = state.objects.find(o => o.uuid === action.objectUuid);
    if (obj) {
      const data = isUndo ? action.before : action.after;
      obj.position.copy(data.position);
      obj.rotation.copy(data.rotation);
      obj.scale.copy(data.scale);

      // If currently selected, update gizmo and panel
      if (state.selectedObject === obj) {
        transformControls.attach(obj);
        updatePropertiesPanel();
        logCalibrationData(obj); // Log on undo/redo too
      }
    }
  }
}

// Global logger for calibration
function logCalibrationData(obj) {
  if (!obj) return;
  const transformData = {
    position: { x: parseFloat(obj.position.x.toFixed(3)), y: parseFloat(obj.position.y.toFixed(3)), z: parseFloat(obj.position.z.toFixed(3)) },
    rotation: { x: parseFloat(obj.rotation.x.toFixed(3)), y: parseFloat(obj.rotation.y.toFixed(3)), z: parseFloat(obj.rotation.z.toFixed(3)) },
    scale: parseFloat(obj.scale.x.toFixed(3))
  };
  console.log(`[Calibration] ${obj.name || 'Object'} Transform:`, JSON.stringify(transformData, null, 2));
}

function setupPropertyInputs() {
  // Name input
  document.getElementById('obj-name').addEventListener('change', (e) => {
    if (state.selectedObject) {
      state.selectedObject.name = e.target.value;
      updateHierarchy();
    }
  });

  // Position inputs
  ['pos-x', 'pos-y', 'pos-z'].forEach((id, i) => {
    document.getElementById(id).addEventListener('input', (e) => {
      if (state.selectedObject) {
        const axis = ['x', 'y', 'z'][i];
        state.selectedObject.position[axis] = parseFloat(e.target.value) || 0;
      }
    });
    document.getElementById(id).addEventListener('change', (e) => {
      if (state.selectedObject) {
        const axis = ['x', 'y', 'z'][i];
        state.selectedObject.position[axis] = parseFloat(e.target.value) || 0;
        logCalibrationData(state.selectedObject);
      }
    });
  });

  // Rotation inputs
  ['rot-x', 'rot-y', 'rot-z'].forEach((id, i) => {
    document.getElementById(id).addEventListener('change', (e) => {
      if (state.selectedObject) {
        const axis = ['x', 'y', 'z'][i];
        state.selectedObject.rotation[axis] = THREE.MathUtils.degToRad(parseFloat(e.target.value) || 0);
        logCalibrationData(state.selectedObject);
      }
    });
  });

  // Scale inputs
  ['scale-x', 'scale-y', 'scale-z'].forEach((id, i) => {
    document.getElementById(id).addEventListener('change', (e) => {
      if (state.selectedObject) {
        const axis = ['x', 'y', 'z'][i];
        state.selectedObject.scale[axis] = parseFloat(e.target.value) || 1;
        logCalibrationData(state.selectedObject);
      }
    });
  });

  // Material color
  document.getElementById('mat-color').addEventListener('input', (e) => {
    if (state.selectedObject && state.selectedObject.material) {
      state.selectedObject.material.color.set(e.target.value);
    }
  });

  // Material metalness
  document.getElementById('mat-metalness').addEventListener('input', (e) => {
    if (state.selectedObject && state.selectedObject.material) {
      state.selectedObject.material.metalness = parseFloat(e.target.value);
      e.target.nextElementSibling.textContent = parseFloat(e.target.value).toFixed(2);
    }
  });

  // Material roughness
  document.getElementById('mat-roughness').addEventListener('input', (e) => {
    if (state.selectedObject && state.selectedObject.material) {
      state.selectedObject.material.roughness = parseFloat(e.target.value);
      e.target.nextElementSibling.textContent = parseFloat(e.target.value).toFixed(2);
    }
  });

  // Light controls
  document.getElementById('light-ambient').addEventListener('input', (e) => {
    ambientLight.intensity = parseFloat(e.target.value);
    e.target.nextElementSibling.textContent = parseFloat(e.target.value).toFixed(1);
  });

  document.getElementById('light-directional').addEventListener('input', (e) => {
    directionalLight.intensity = parseFloat(e.target.value);
    e.target.nextElementSibling.textContent = parseFloat(e.target.value).toFixed(1);
  });
}

// ============================================
// Learning Platform functions
// ============================================
const learningState = {
  currentSubject: 'physics',
  currentLessonId: null,
  currentLessonModule: null,
  lessonObjects: []
};

function getLessonsForSubject(subject) {
  switch (subject) {
    case 'physics': return Object.values(PhysicsLessons);
    case 'biology': return Object.values(BiologyLessons);
    case 'chemistry': return Object.values(ChemistryLessons);
    case 'engineering': return [...Object.values(EngineeringLessons), ...Object.values(RoboticsLessons)];
    default: return [];
  }
}

function renderLessons(subject) {
  const list = document.getElementById('lessons-list');
  if (!list) return;

  // Update context for AI
  if (aiTutor) {
    aiTutor.setContext({ topic: subject });
  }

  const subjectLessons = getLessonsForSubject(subject);

  list.innerHTML = subjectLessons.map(lesson => `
        <div class="lesson-card" data-lesson-id="${lesson.id}">
            <div class="lesson-card-header">
                <div class="lesson-icon">
                    <span class="material-icons-round">science</span>
                </div>
                <span class="lesson-title">${lesson.name}</span>
            </div>
            <p class="lesson-desc">${lesson.description || lesson.desc}</p>
        </div>
    `).join('');

  // Add click handlers
  list.querySelectorAll('.lesson-card').forEach(card => {
    card.addEventListener('click', () => loadLesson(card.dataset.lessonId));
  });
}

function loadLesson(lessonId) {
  // Stop any running simulation
  if (physics && physics.isRunning) {
    physics.stop();
    updateSimStatus();
  }

  // Clear previous lesson objects
  clearLessonObjects();

  // Find lesson module
  const lessons = getLessonsForSubject(learningState.currentSubject);
  const lesson = lessons.find(l => l.id === lessonId);

  if (!lesson) {
    console.error('Lesson not found:', lessonId);
    return;
  }

  learningState.currentLessonId = lessonId;
  learningState.currentLessonModule = lesson;

  // Update UI
  document.querySelectorAll('.lesson-card').forEach(c => c.classList.remove('active'));
  const card = document.querySelector(`.lesson-card[data-lesson-id="${lessonId}"]`);
  if (card) card.classList.add('active');

  // Update Lesson Info Overlay
  const infoOverlay = document.getElementById('lesson-info-overlay');
  if (infoOverlay) {
    document.getElementById('lesson-title').textContent = lesson.name;
    document.getElementById('lesson-description').textContent = lesson.description;

    // Formula
    const formulaContainer = document.querySelector('.formula-display');
    if (lesson.formula) {
      formulaContainer.textContent = lesson.formula;
      formulaContainer.classList.remove('hidden');
    } else {
      formulaContainer.classList.add('hidden');
    }

    infoOverlay.classList.remove('hidden');
  }

  // Setup 3D Scene
  if (lesson.setup) {
    try {
      const result = lesson.setup(scene, physics, THREE);
      if (result && result.objects) {
        // Add objects to state
        learningState.lessonObjects = result.objects;
        result.objects.forEach(obj => {
          if (!state.objects.includes(obj)) {
            state.objects.push(obj);
          }
        });

        // Store extra data for updates
        learningState.lessonData = result;

        updateHierarchy();
        setStatus(`${lesson.name} 레슨 로드됨`);

        // Update AI context
        if (aiTutor) {
          aiTutor.setContext({
            subject: learningState.currentSubject,
            topic: lesson.topic,
            experiment: lesson.name
          });
        }

        // Initial Physics Setup if needed (but waited for start)
      }
    } catch (e) {
      console.error('Lesson setup error:', e);
      setStatus(`레슨 로드 중 오류: ${e.message}`);
    }
  }
}

function clearLessonObjects() {
  // Remove physics bodies
  if (physics) {
    learningState.lessonObjects.forEach(obj => {
      physics.removeBody(obj);
    });
    physics.reset();
  }

  // Remove meshes
  learningState.lessonObjects.forEach(obj => {
    scene.remove(obj);
    const idx = state.objects.indexOf(obj);
    if (idx > -1) state.objects.splice(idx, 1);

    // Dispose
    if (obj.geometry) obj.geometry.dispose();
    if (obj.material) {
      if (Array.isArray(obj.material)) {
        obj.material.forEach(m => m.dispose());
      } else {
        obj.material.dispose();
      }
    }
  });

  // Remove helpers/lines created dynamically
  scene.children.forEach(child => {
    if (child.name.startsWith('Pendulum_String') || child.name.includes('Helper')) { // Cleanup specific helpers if missed
      scene.remove(child);
    }
  });

  learningState.lessonObjects = [];
  learningState.lessonData = null;
  learningState.currentLessonId = null;
  learningState.currentLessonModule = null;

  updateHierarchy();

  // Hide overlay
  document.getElementById('lesson-info-overlay')?.classList.add('hidden');
}

function updateLessonInfo() {
  const lesson = learningState.currentLessonModule;
  const data = learningState.lessonData;

  if (lesson && lesson.getInfo && data && physics) {
    const info = lesson.getInfo(physics, data.mainObject || data.objects[0]);
    if (info) {
      const container = document.querySelector('.data-display');
      container.innerHTML = Object.entries(info).map(([key, value]) => `
                <div class="data-row">
                    <span>${key}</span>
                    <span class="data-value">${value}</span>
                </div>
            `).join('');
    }
  }

  // Custom update loop for non-physics animations (like pendulum string)
  if (lesson && lesson.onUpdate && data) {
    lesson.onUpdate(data, physics);
  }
}

function setupLearningPlatform() {
  // Subject tabs
  document.querySelectorAll('.subject-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.subject-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      learningState.currentSubject = tab.dataset.subject;
      renderLessons(tab.dataset.subject);
    });
  });

  // Panel tabs
  document.querySelectorAll('.panel-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.panel-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      tab.classList.add('active');
      const panel = document.getElementById(`${tab.dataset.panel}-panel`);
      if (panel) panel.classList.add('active');
    });
  });

  // Simulation controls
  const btnPlay = document.getElementById('sim-play');
  const btnPause = document.getElementById('sim-pause');
  const btnStop = document.getElementById('sim-stop');

  if (btnPlay) btnPlay.addEventListener('click', () => {
    if (physics && learningState.currentLessonModule) {
      // If starting from stopped state and has onStart
      if (!physics.isRunning && learningState.currentLessonModule.onStart) {
        // Initialize physics bodies only when starting
        learningState.currentLessonModule.onStart(learningState.lessonData, physics);
      }
      physics.start();
      updateSimStatus();
    }
  });

  if (btnPause) btnPause.addEventListener('click', () => {
    if (physics) {
      physics.pause();
      updateSimStatus();
    }
  });

  if (btnStop) btnStop.addEventListener('click', () => {
    if (physics) {
      physics.stop();
      // Reset objects by reloading
      if (learningState.currentLessonId) {
        loadLesson(learningState.currentLessonId);
      }
      updateSimStatus();
    }
  });

  document.getElementById('sim-speed')?.addEventListener('input', (e) => {
    if (physics) {
      physics.setTimeScale(parseFloat(e.target.value));
      document.getElementById('speed-value').textContent = e.target.value + 'x';
    }
  });

  // Explode view toggle for robotics lessons
  document.getElementById('sim-explode')?.addEventListener('click', () => {
    const lesson = learningState.currentLessonModule;
    if (lesson && lesson.toggleExplode && learningState.lessonObjects.length > 0) {
      lesson.toggleExplode(learningState.lessonObjects);
      setStatus(learningState.lessonObjects[0]?.userData?.isExploded ? '분해도 보기 ON' : '분해도 보기 OFF');
    }
  });

  // AI Chat
  const chatInput = document.querySelector('.chat-input');
  const btnSend = document.querySelector('.btn-send');

  const sendMessage = async () => {
    const text = chatInput.value.trim();
    if (!text) return;

    // Add user message
    addChatMessage(text, 'user');
    chatInput.value = '';

    // Show loading or typing indicator could go here

    if (aiTutor) {
      const result = await aiTutor.sendMessage(text);
      if (result.success) {
        addChatMessage(result.message, 'ai');
      } else {
        addChatMessage(`오류: ${result.error}`, 'ai');
      }
    }
  };

  if (btnSend) btnSend.addEventListener('click', sendMessage);
  if (chatInput) chatInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') sendMessage();
  });

  // Initial Render
  renderLessons('physics');
  updateApiKeyStatus();

  // Settings modal
  document.getElementById('btn-settings')?.addEventListener('click', () => openModal('settings-modal'));

  // API key handling
  document.getElementById('btn-save-api-key')?.addEventListener('click', () => {
    const key = document.getElementById('api-key-input')?.value;
    if (key && aiTutor) {
      aiTutor.setApiKey(key);
      updateApiKeyStatus();
      setStatus('API 키가 저장되었습니다');
      openModal('settings-modal'); // Keep open or close? Let's close
      closeModal('settings-modal');
    }
  });

  document.getElementById('btn-clear-api-key')?.addEventListener('click', () => {
    if (aiTutor) {
      aiTutor.clearApiKey();
      updateApiKeyStatus();
    }
  });
}

function addChatMessage(text, role) {
  const container = document.querySelector('.chat-messages');
  if (!container) return;

  const msgDiv = document.createElement('div');
  msgDiv.className = `chat-message ${role}`;

  const avatar = role === 'ai' ? 'smart_toy' : 'person';

  msgDiv.innerHTML = `
        <div class="message-avatar">
            <span class="material-icons-round">${avatar}</span>
        </div>
        <div class="message-content">
            ${text}
        </div>
    `;

  container.appendChild(msgDiv);
  container.scrollTop = container.scrollHeight;
}

function updateSimStatus() {
  const icon = document.getElementById('sim-status-icon');
  const text = document.getElementById('sim-status-text');
  const status = document.querySelector('.sim-status');

  const isRunning = physics && physics.isRunning;

  if (isRunning) {
    icon.textContent = 'play_circle';
    text.textContent = '실행 중';
    status?.classList.add('running');
    status?.classList.remove('paused');
  } else {
    icon.textContent = 'pause_circle';
    text.textContent = '정지됨';
    status?.classList.remove('running');
    status?.classList.add('paused');
  }
}

function updateApiKeyStatus() {
  if (!aiTutor) return;

  const hasKey = aiTutor.checkConfiguration();
  const statusEl = document.getElementById('ai-status');
  const statusText = document.getElementById('ai-status-text');
  const keyStatus = document.getElementById('api-key-status-text');

  if (hasKey) {
    statusEl?.classList.add('configured');
    if (statusText) statusText.textContent = 'API 연결됨';
    if (keyStatus) keyStatus.textContent = 'API 키 저장됨';
  } else {
    statusEl?.classList.remove('configured');
    if (statusText) statusText.textContent = 'API 키 미설정';
    if (keyStatus) keyStatus.textContent = '저장된 API 키 없음';
  }
}

// ============================================
// Initialize Application
// ============================================
function init() {
  initScene();
  setupEventListeners();
  setupLearningPlatform();
  animate();

  console.log('🔬 3D Science Lab initialized');
}

// Start the application
init();
